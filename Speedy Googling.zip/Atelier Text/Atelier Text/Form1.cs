﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Atelier_Text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "www.google.com";
           
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            
           
          //   http://www.th3matrex.com
        }

        private void label3_Click(object sender, EventArgs e)
        {
            ActiveForm.WindowState = FormWindowState.Minimized;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("        A very Light Browser for Google Searching " +
               "\n       Please Donate To : atlas.emirat@gmail.com" + "\n   Find More At : https://Atlas-shark.blogspot.com ", "Developed By Atlas Shark");
 ActiveForm.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            webBrowser1.Url = new Uri("https://" + textBox1.Text);
            webBrowser1.AllowNavigation = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ActiveForm.FormBorderStyle == FormBorderStyle.Fixed3D) ActiveForm.FormBorderStyle = FormBorderStyle.None;
            else ActiveForm.FormBorderStyle = FormBorderStyle.Fixed3D;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                
                WindowState = FormWindowState.Maximized;
                //browser width & height +
                webBrowser1.Height += 225; //(28 * webBrowser1.Height) / 100;
                webBrowser1.Width += 335;//(27 * webBrowser1.Width) / 100;
                label6.Hide();
                button2.Hide();
                //top+
                label4.Location = new Point(label4.Location.X + 200, label4.Location.Y);
                label5.Location = new Point(label5.Location.X + 200, label5.Location.Y);
                label2.Location = new Point(label2.Location.X + 200, label2.Location.Y);
                label3.Location = new Point(label3.Location.X + 200, label3.Location.Y);
                button1.Location = new Point(button1.Location.X + 200, button1.Location.Y);
                //Url+
                label1.Location = new Point(label1.Location.X + 90, label1.Location.Y + 10);
                textBox1.Location = new Point(textBox1.Location.X + 90, textBox1.Location.Y + 10);
                textBox1.Width += 160;
                button7.Location = new Point(button7.Location.X + 250, button7.Location.Y + 10);
            }
            else
            {
                WindowState = FormWindowState.Normal;
                button2.Show();
                //Url -
                label1.Location = new Point(label1.Location.X - 90, label1.Location.Y - 10);
                textBox1.Location = new Point(textBox1.Location.X - 90, textBox1.Location.Y - 10);
                textBox1.Width -= 160;
                button7.Location = new Point(button7.Location.X - 250, button7.Location.Y - 10);
                //top -
                label4.Location = new Point(label4.Location.X - 200, label4.Location.Y); 
                label5.Location = new Point(label5.Location.X - 200, label5.Location.Y);
                label2.Location = new Point(label2.Location.X - 200, label2.Location.Y);
                label3.Location = new Point(label3.Location.X - 200, label3.Location.Y);
                button1.Location = new Point(button1.Location.X - 200, button1.Location.Y);
                //browser width & height -
                webBrowser1.Height -= 225; //(28* webBrowser1.Height) / 100;
                webBrowser1.Width -= 335; //(27 * webBrowser1.Width) / 100;
            }
        }
    }
}
